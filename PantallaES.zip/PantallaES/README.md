# Pantalla ES

App Android (Kotlin) que traduce al español lo que aparece en pantalla, en cualquier app y desde cualquier idioma.

## Cómo funciona

1. **Captura**: `MediaProjection` saca una imagen de la pantalla (sin nuestros propios botones ni capas).
2. **OCR**: ML Kit lee el texto en 5 alfabetos (latino, chino, japonés, coreano, devanagari).
3. **Detección de idioma**: ML Kit Language ID decide de qué idioma es cada bloque.
4. **Traducción con IA**: ML Kit Translate (modelos neuronales) lo pasa a español.
5. **Overlay**: se pinta la traducción encima del texto original, con el color de fondo de la app.

Todo se ejecuta **en el móvil**. Solo hay conexión para descargar el modelo de cada idioma la primera vez (~30 MB por idioma).

## Compilar

1. Abre la carpeta `PantallaES` con **Android Studio** (Koala o superior). Genera el wrapper de Gradle y sincroniza solo.
2. Conecta el móvil (Android 8.0+) con depuración USB y pulsa **Run**.

## Usar

1. Abre **Pantalla ES** y pulsa **Iniciar**.
2. Concede "Mostrar sobre otras apps", notificaciones, y en el diálogo de captura elige **Toda la pantalla**.
3. Abre cualquier app. Aparece un botón flotante azul **ES**:
   - **Toque**: traduce la pantalla / quita la traducción.
   - **Pulsación larga**: modo en vivo (botón verde), se actualiza cada ~1 s.
   - **Arrastrar**: lo mueves donde quieras.
4. Para parar: botón **Detener** en la app o en la notificación.

## Limitaciones conocidas

- Si giras el móvil, detén y vuelve a iniciar para que se ajuste el tamaño.
- En modo en vivo, la traducción parpadea brevemente en cada actualización (se oculta para capturar la pantalla limpia).
- Apps con contenido protegido (banca, DRM) bloquean la captura de pantalla.
- La calidad depende del OCR: texto muy pequeño, estilizado o sobre fotos puede fallar.
- Android 14+ pide permiso de captura cada vez que inicias el servicio (es una norma del sistema).

## Mejoras posibles

- Sustituir ML Kit Translate por un modelo en la nube (p. ej. Claude API) para traducciones más naturales en contexto.
- Accessibility Service para leer el texto directamente de la UI (más rápido y preciso en apps nativas).
