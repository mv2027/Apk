package com.pantalla.es

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, TranslatorService::class.java)
                    .putExtra(TranslatorService.EXTRA_CODE, r.resultCode)
                    .putExtra(TranslatorService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                Toast.makeText(
                    this,
                    "Listo. Abre cualquier app y toca el botón flotante \"ES\".",
                    Toast.LENGTH_LONG
                ).show()
                moveTaskToBack(true)
            }
        }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { askProjection() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "Pantalla ES"
            textSize = 32f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "Traduce al español lo que haya en pantalla, en cualquier app y desde " +
                "cualquier idioma. Todo se procesa en tu móvil.\n\n" +
                "• Toque en el botón \"ES\": traduce la pantalla una vez.\n" +
                "• Toque otra vez: quita la traducción.\n" +
                "• Pulsación larga: modo en vivo (se actualiza solo).\n\n" +
                "Cuando Android te pregunte qué compartir, elige \"Toda la pantalla\"."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, pad / 2, 0, pad)
        })

        root.addView(Button(this).apply {
            text = "Iniciar"
            setOnClickListener { startFlow() }
        })
        root.addView(Button(this).apply {
            text = "Detener"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TranslatorService::class.java))
            }
        })

        setContentView(root)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(
                this,
                "Activa \"Mostrar sobre otras apps\" y vuelve a pulsar Iniciar.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        askProjection()
    }

    private fun askProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
