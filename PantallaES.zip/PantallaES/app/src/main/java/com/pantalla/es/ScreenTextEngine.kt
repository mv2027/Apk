package com.pantalla.es

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.tasks.await
import java.util.concurrent.ConcurrentHashMap

/** Un texto ya traducido, con su posición en pantalla y colores de fondo/texto. */
data class Item(val rect: Rect, val text: String, val bg: Int, val fg: Int)

class Output(val items: List<Item>, val error: String?)

/**
 * Pipeline: OCR (5 alfabetos) -> detección de idioma -> traducción neuronal a español.
 * Todo corre en el dispositivo con ML Kit. Solo se descargan los modelos de idioma
 * la primera vez que se necesita cada uno (~30 MB).
 */
class ScreenTextEngine {

    private val recognizers = listOf(
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
        TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
        TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()),
        TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()),
    )
    private val langId = LanguageIdentification.getClient()
    private val translators = HashMap<String, Translator>()
    private val ready = ConcurrentHashMap.newKeySet<String>()
    private val cache = ConcurrentHashMap<String, String>() // "" = no traducir

    suspend fun process(bmp: Bitmap): Output = coroutineScope {
        val image = InputImage.fromBitmap(bmp, 0)

        // 1) OCR con todos los alfabetos en paralelo
        val raw = recognizers.map { r ->
            async {
                try {
                    r.process(image).await().textBlocks
                } catch (e: Exception) {
                    emptyList<Text.TextBlock>()
                }
            }
        }.awaitAll().flatten()

        // 2) Quitar duplicados (varios reconocedores leen la misma zona)
        val candidates = raw
            .filter { it.boundingBox != null && it.text.trim().length >= 2 }
            .sortedByDescending { it.text.length }
        val kept = ArrayList<Text.TextBlock>()
        for (b in candidates) {
            val r = b.boundingBox!!
            if (kept.none { overlaps(it.boundingBox!!, r) }) kept += b
        }

        // 3) Detectar idioma y traducir
        var error: String? = null
        val items = kept.map { b ->
            async {
                try {
                    val rect = Rect(b.boundingBox!!)
                    val src = b.text.replace('\n', ' ').trim()
                    val es = translate(src)
                    if (es == null) null else {
                        val (bg, fg) = colorsAt(bmp, rect)
                        Item(rect, es, bg, fg)
                    }
                } catch (e: Exception) {
                    error = "No se pudo traducir (¿sin internet para descargar el idioma?)"
                    null
                }
            }
        }.awaitAll().filterNotNull()

        Output(items, error)
    }

    private suspend fun translate(text: String): String? {
        if (!text.any { it.isLetter() }) return null
        cache[text]?.let { return it.ifEmpty { null } }

        val lang = langId.identifyLanguage(text).await()
        val src = if (lang == "und" || lang == "es") null else TranslateLanguage.fromLanguageTag(lang)
        if (src == null) {
            cache[text] = ""
            return null
        }

        val translator = synchronized(translators) {
            translators.getOrPut(src) {
                Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(src)
                        .setTargetLanguage(TranslateLanguage.SPANISH)
                        .build()
                )
            }
        }
        if (!ready.contains(src)) {
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            ready.add(src)
        }
        val es = translator.translate(text).await()
        cache[text] = es
        return es
    }

    private fun overlaps(a: Rect, b: Rect): Boolean {
        val i = Rect(a)
        if (!i.intersect(b)) return false
        val inter = i.width().toLong() * i.height()
        val smaller = minOf(
            a.width().toLong() * a.height(),
            b.width().toLong() * b.height()
        ).coerceAtLeast(1)
        return inter.toDouble() / smaller > 0.5
    }

    /** Toma el color de fondo de la pantalla junto al texto para que la traducción "encaje". */
    private fun colorsAt(bmp: Bitmap, r: Rect): Pair<Int, Int> {
        val x = (r.left + 2).coerceIn(0, bmp.width - 1)
        val y = (r.top + 2).coerceIn(0, bmp.height - 1)
        val px = bmp.getPixel(x, y)
        val bg = Color.rgb(Color.red(px), Color.green(px), Color.blue(px))
        val lum = (0.299 * Color.red(px) + 0.587 * Color.green(px) + 0.114 * Color.blue(px)) / 255
        return bg to (if (lum > 0.55) Color.BLACK else Color.WHITE)
    }

    fun close() {
        recognizers.forEach { it.close() }
        langId.close()
        synchronized(translators) { translators.values.forEach { it.close() } }
    }
}
