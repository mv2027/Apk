package com.pantalla.es

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class TranslatorService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.pantalla.es.STOP"
        private const val CHANNEL = "pantalla_es"
        private const val NOTIF_ID = 1

        private const val COLOR_IDLE = 0xE61A73E8.toInt()
        private const val COLOR_LIVE = 0xE634A853.toInt()
        private const val COLOR_BUSY = 0xE6F9AB00.toInt()
    }

    private val wm by lazy { getSystemService(WindowManager::class.java) }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: OverlayView? = null
    private var fab: TextView? = null
    private var engine: ScreenTextEngine? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var liveJob: Job? = null
    private var busy = false
    private var live = false

    // Captura: solo convertimos fotogramas mientras "collecting" es true.
    private var collecting = false
    private var latest: Bitmap? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY

        startAsForeground()

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        // Android 14+: hay que registrar el callback antes de crear el VirtualDisplay.
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))
        projection = proj

        engine = ScreenTextEngine()
        setupCapture(proj)
        setupOverlay()
        return START_NOT_STICKY
    }

    // ---------- Notificación ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Traducción de pantalla", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, TranslatorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Pantalla ES activa")
            .setContentText("Toca el botón flotante \"ES\" para traducir")
            .addAction(0, "Detener", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
    }

    // ---------- Captura de pantalla ----------

    private fun setupCapture(proj: MediaProjection) {
        val size = screenSize()
        val r = ImageReader.newInstance(size.x, size.y, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (collecting) {
                    latest?.recycle()
                    latest = img.toBitmap()
                }
            } finally {
                img.close()
            }
        }, Handler(Looper.getMainLooper()))
        reader = r
        display = proj.createVirtualDisplay(
            "pantalla_es", size.x, size.y, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    /** Oculta nuestras capas, espera un fotograma limpio y lo devuelve. */
    private suspend fun capture(): Bitmap? {
        collecting = true
        latest = null
        overlay?.visibility = View.INVISIBLE
        fab?.visibility = View.INVISIBLE
        try {
            delay(220)
        } finally {
            collecting = false
        }
        val bmp = latest
        latest = null
        return bmp
    }

    private fun Image.toBitmap(): Bitmap {
        val plane = planes[0]
        val rowPadding = plane.rowStride - plane.pixelStride * width
        val bmp = Bitmap.createBitmap(
            width + rowPadding / plane.pixelStride, height, Bitmap.Config.ARGB_8888
        )
        bmp.copyPixelsFromBuffer(plane.buffer)
        if (rowPadding == 0) return bmp
        return Bitmap.createBitmap(bmp, 0, 0, width, height).also { bmp.recycle() }
    }

    // ---------- Overlay y botón flotante ----------

    private fun setupOverlay() {
        val size = screenSize()

        val ov = OverlayView(this)
        val ovParams = WindowManager.LayoutParams(
            size.x, size.y,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        ov.visibility = View.INVISIBLE
        wm.addView(ov, ovParams)
        overlay = ov

        val f = TextView(this).apply {
            text = "ES"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(COLOR_IDLE)
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(52), dp(52),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(220)
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false

        val gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                onTap()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!moved) setLive(!live)
            }
        })

        f.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = ev.rawX; downY = ev.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (moved || abs(dx) > slop || abs(dy) > slop) {
                        moved = true
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        wm.updateViewLayout(f, lp)
                    }
                }
            }
            if (moved) true else gestures.onTouchEvent(ev)
        }
        wm.addView(f, lp)
        fab = f
    }

    private fun setFab(color: Int, label: String) {
        fab?.let {
            (it.background as GradientDrawable).setColor(color)
            it.text = label
        }
    }

    // ---------- Lógica de traducción ----------

    private fun onTap() {
        if (live) {
            setLive(false)
            return
        }
        val ov = overlay
        if (ov != null && ov.visibility == View.VISIBLE && ov.items.isNotEmpty()) {
            ov.items = emptyList()
            ov.visibility = View.INVISIBLE
            return
        }
        scope.launch { cycle() }
    }

    private fun setLive(on: Boolean) {
        live = on
        liveJob?.cancel()
        if (on) {
            toast("Modo en vivo activado")
            liveJob = scope.launch {
                while (isActive) {
                    cycle()
                    delay(1000)
                }
            }
        } else {
            overlay?.items = emptyList()
            overlay?.visibility = View.INVISIBLE
            setFab(COLOR_IDLE, "ES")
            toast("Modo en vivo desactivado")
        }
    }

    private suspend fun cycle() {
        val eng = engine ?: return
        val ov = overlay ?: return
        if (busy) return
        busy = true
        try {
            setFab(COLOR_BUSY, "…")
            val bmp = capture()
            fab?.visibility = View.VISIBLE
            if (bmp == null) {
                toast("No se pudo capturar la pantalla")
                return
            }
            val out = withContext(Dispatchers.Default) { eng.process(bmp) }
            bmp.recycle()

            ov.items = out.items
            ov.visibility = View.VISIBLE
            out.error?.let { toast(it) }
            if (out.items.isEmpty() && !live && out.error == null) {
                toast("No encontré texto para traducir")
            }
        } finally {
            busy = false
            fab?.visibility = View.VISIBLE
            setFab(if (live) COLOR_LIVE else COLOR_IDLE, "ES")
        }
    }

    // ---------- Utilidades ----------

    private fun screenSize(): Point =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            Point(m.widthPixels, m.heightPixels)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        scope.cancel()
        overlay?.let { runCatching { wm.removeView(it) } }
        fab?.let { runCatching { wm.removeView(it) } }
        display?.release()
        reader?.close()
        projection?.stop()
        engine?.close()
        latest?.recycle()
        super.onDestroy()
    }
}
