package com.pantalla.es

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

/** Capa a pantalla completa que pinta las traducciones encima del texto original. */
class OverlayView(context: Context) : View(context) {

    var items: List<Item> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    private val bgPaint = Paint().apply { style = Paint.Style.FILL }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density

    override fun onDraw(canvas: Canvas) {
        val maxSize = 20f * density
        val minSize = 9f * density

        for (item in items) {
            val w = item.rect.width().coerceAtLeast(1)
            val h = item.rect.height().coerceAtLeast(1)

            textPaint.color = item.fg
            var size = (h * 0.8f).coerceIn(minSize, maxSize)
            var layout = build(item.text, w, size)
            while (layout.height > h && size > minSize) {
                size -= density
                layout = build(item.text, w, size)
            }

            // Si aun así no cabe, el recuadro crece hacia abajo.
            val bottom = item.rect.top + maxOf(h, layout.height)
            bgPaint.color = item.bg
            canvas.drawRect(
                RectF(
                    item.rect.left.toFloat(), item.rect.top.toFloat(),
                    item.rect.right.toFloat(), bottom.toFloat()
                ),
                bgPaint
            )

            canvas.save()
            canvas.translate(item.rect.left.toFloat(), item.rect.top.toFloat())
            layout.draw(canvas)
            canvas.restore()
        }
    }

    private fun build(text: String, width: Int, size: Float): StaticLayout {
        textPaint.textSize = size
        return StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()
    }
}
